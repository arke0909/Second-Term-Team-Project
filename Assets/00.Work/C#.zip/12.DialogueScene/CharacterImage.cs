using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class CharacterImage : MonoBehaviour
{
    public string characterName;
    public Image image;
}
