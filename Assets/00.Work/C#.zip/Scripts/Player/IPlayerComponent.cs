public interface IPlayerComponent
{
    void Initialize(Player player);
}
