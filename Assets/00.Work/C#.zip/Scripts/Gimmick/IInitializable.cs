public interface IInitializable
{
    public void Initialze();
}
